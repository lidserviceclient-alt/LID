
document.addEventListener('DOMContentLoaded', function() {
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.textContent = JSON.stringify({
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Comment fonctionne Lid App ?",
        "acceptedAnswer": { "@type": "Answer", "text": "Lid est une marketplace e-commerce qui permet aux utilisateurs d'acheter et de vendre des produits en ligne facilement. Créez votre compte, parcourez des milliers de produits ou ouvrez votre boutique en quelques clics." }
      },
      {
        "@type": "Question",
        "name": "Les paiements sont-ils sécurisés ?",
        "acceptedAnswer": { "@type": "Answer", "text": "Oui, tous les paiements sur Lid sont 100% sécurisés. Nous utilisons des protocoles de sécurité avancés et supportons Mobile Money, cartes bancaires et autres méthodes de paiement fiables." }
      },
      {
        "@type": "Question",
        "name": "Comment vendre sur Lid App ?",
        "acceptedAnswer": { "@type": "Answer", "text": "Pour vendre sur Lid, inscrivez-vous gratuitement, créez votre boutique, ajoutez vos produits avec photos et descriptions, puis commencez à recevoir des commandes." }
      }
    ]
  });
  document.head.appendChild(script);
});
