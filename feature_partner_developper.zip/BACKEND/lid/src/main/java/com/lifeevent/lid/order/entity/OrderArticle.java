package com.lifeevent.lid.order.entity;

import com.lifeevent.lid.article.entity.Article;
import com.lifeevent.lid.common.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Table(
        name = "order_article",
        indexes = {
                @Index(name = "idx_order_article_order", columnList = "order_id"),
                @Index(name = "idx_order_article_article", columnList = "article_id")
        }
)
public class OrderArticle extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Order order;

    @ManyToOne
    private Article article;

    private Integer quantity;

    private Double priceAtOrder;
}
